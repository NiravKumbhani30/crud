import connectMongo from "../../../database/conn";
import {
  getUsers,
  postUser,
  putUser,
  deleteUser,
} from "../../../database/controller";

export default async function handler(req, res) {
  connectMongo().catch(() =>
    res.status(405).json({ error: "Error in the connection" })
  );

  const { method } = req;

  switch (method) {
    case "GET":
      getUsers(req, res);
      break;

    case "POST":
      postUser(req, res);
      break;

    default:
      res.setHader("Allow", ["GET", "POST", "PUT", "DELETE"]);
      res.status(405).end(`method ${method} Not Allow`);
      break;
  }
}
